#! /bin/bash

## for festuca
SELSTR=(VS00 VS33 VS50)
env_variance=("{{2.7,32,1}}" "{{2,14,1}}" "{{2.4,20,1}}")
selstrength=("{{459,36031,9}}" "{{153,12011,3}}" "{{229,18015,4.35}}")
mutation=(0.01 0.001 0.0001)

path="/mnt/simuls/climate_change/"

SAADLT=(0.7 0.8 0.9)
competition=(0.00025 0.00041 0.0009)

for grid in 7 8 10 11 12 13 14 15

do

	for sce in 0 1 2 3
	
	do 
	
		for sa in sa07 sa08 sa09
		
		do
		
			if [ $sa == "sa07" ]; then SA=${SAADLT[0]}; COMP=${competition[0]}; fi;
			if [ $sa == "sa08" ]; then SA=${SAADLT[1]}; COMP=${competition[1]}; fi;
			if [ $sa == "sa09" ]; then SA=${SAADLT[2]}; COMP=${competition[2]}; fi;
		
			for mut in 0100 0010 0001
			
			do
			
			if [ $mut=="0100" ]; then MUT=${mutation[0]};fi;
			if [ $mut=="0010" ]; then MUT=${mutation[1]};fi;
			if [ $mut=="0001" ]; then MUT=${mutation[2]};fi;
			
				for sel in vs vs33 vs50
				
				do
				
				if [ $sel == "vs" ]; then SEL=${SELSTR[0]}; SELVEC=${selstrength[0]}; ENVVAR=${env_variance[0]}; fi;
				if [ $sel == "vs33" ]; then SEL=${SELSTR[1]}; SELVEC=${selstrength[1]}; ENVVAR=${env_variance[2]}; fi;
				if [ $sel == "vs50" ]; then SEL=${SELSTR[2]}; SELVEC=${selstrength[2]}; ENVVAR=${env_variance[2]}; fi;
				
					
				sim=s${sce}_festuca_g${grid}_${sa}_m${mut}_${SEL}
					
				#check if the bygen is locally present:
			  if ! [ -e $path${sim}_bygen.txt ]
				  
				  then
					
 					sed -e "s/(selection)/$sel/g" -e "s/(survieadulte)/$sa/g" -e "s/(scenario)/$sce/g" -e "s/(mut)/$mut/g" -e "s/(grid)/$grid/g" -e "s/(SELECTION)/$SEL/g" -e "s/(COMP)/$COMP/g" -e "s/(SAGEVAR)/$SELVEC/g" -e "s/(QUANTIEVAR)/$ENVVAR/g" -e "s/(SA)/$SA/g" -e "s/(MUT)/$MUT/" -e "s/(random)/$RANDOM/" festuca_template.ini > festuca/${sim}.ini
					
					fi

				done
				
			done
			
		done
	done
done


